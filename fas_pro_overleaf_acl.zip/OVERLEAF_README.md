Upload this ZIP to a new Overleaf project. The main document is main.tex. Use pdfLaTeX and compile twice. This is the ACL article version, not the UMAC thesis format.
