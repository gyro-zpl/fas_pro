# Overleaf import instructions`n`nUpload this ZIP to a new Overleaf project. Set the compiler to pdfLaTeX and set main.tex as the Main document. Compile twice for references and cross-references.`n
