# Master's Thesis (UMAC FST)

**Title:** From Prompting to Structured Alignment: Individual, Population, and Temporal Boundaries of LLM Survey Simulation

**Author:** CHENYU YUAN
**Supervisor:** PENGYANG WANG
**Degree:** Master of Computer Science
**Department:** Computer Science, Faculty of Science and Technology, University of Macau
**Date:** April 2027

## Format

Follows the UMAC FST master's thesis template:

- A4 paper
- Times New Roman 12pt body, 1.5 line spacing
- Margins: left 1.5in (binding side), right 1in, top 1in, bottom 1in
- Chapter headings 14pt, captions 10pt
- Front matter: title page, abstract, TOC, list of figures, list of tables, list of abbreviations
- Page numbers: preliminary pages bottom center (TOC first page unnumbered); text pages top center; first page of each chapter/bibliography/appendix counted but unnumbered
- Table captions above tables; figure captions below figures
- Main body: Chapters 1--5, **17 pages**
- Back matter: bibliography, appendices A--D, vita (not listed in TOC)

## Build

```bash
cd thesis
tectonic main.tex
```

or with a standard TeX installation:

```bash
pdflatex main
bibtex main
pdflatex main
pdflatex main
```

The compiled PDF is **not committed**; build it with `tectonic main.tex` (39 pages
total, 17-page main body at the last build). The Overleaf package is
`fas_pro_overleaf_thesis.zip`.

## Structure

```text
thesis/
├── main.tex              # preamble, title page, abstract, front matter
├── chapters/
│   ├── 01_intro.tex      # introduction + related work
│   ├── 02_method.tex     # data construction + method
│   ├── 03_results.tex    # effect ladder + error profile + population
│   ├── 04_temporal.tex   # temporal and validity analysis + ablations
│   └── 05_conclusion.tex # limitations + conclusion
├── appendix/
│   ├── A_data.tex        # data audit, splits, sampling, features
│   ├── B_results.tex     # per-year table, ablations, cross-pressure
│   ├── C_fas.tex         # full FAS table, prompts, hyperparameters
│   └── D_second_family.tex # DeepSeek-R1-Distill-Llama-8B robustness check
├── tables/
│   ├── table2_pas.tex        # effect ladder
│   ├── table3_fas.tex        # population-level JS
│   └── table3b_profile.tex   # error profile by true-score quartile
├── figures/
│   ├── fig1_pipeline.pdf      # architecture of the PAS and FAS pipelines
│   ├── fig2_temporal_decay.pdf
│   └── figure1.svg            # editable source of fig1_pipeline.pdf
├── references.bib
└── OVERLEAF_README.md
```

`archive/` contains the earlier, longer chapter drafts (not compiled; excluded
from the pushed copy).
